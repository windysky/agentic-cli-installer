# Performance and Logic Issues - Analysis and Fixes

## Overview

This document summarizes the analysis and fixes for performance and logic issues in the `install_coding_tools.sh` script.

## Issues Identified

### 1. PERF-002: Stream version fetch results

**Severity:** Medium
**Location:** `prefetch_latest_versions()` function (lines 836-906)

**Problem:** The script waits for ALL version fetch subprocesses to complete before processing ANY results. This delays showing progress to users.

**Fix:** Process each result immediately when its subprocess completes, rather than waiting for all to finish.

**Impact:** Users see version information earlier as results stream in.

---

### 2. PERF-003: Cache subprocess paths

**Severity:** High
**Location:** Global variables, `get_conda_root()`, `get_npm_bin()`, `get_npm_node_bin()`

**Problem:** Functions that detect npm/conda paths are called multiple times but don't cache results, causing redundant subprocess calls.

**Fix:**
- Add cache variables: `_CACHED_NPM_BIN`, `_CACHED_NODE_BIN`, `_CACHED_CONDA_ROOT`
- Update functions to check cache first before running subprocess commands
- Store results in cache on first successful lookup

**Impact:** Eliminates redundant subprocess calls, significantly improving performance when these functions are called multiple times.

---

### 3. LOG-002: PATH race condition

**Severity:** High
**Location:** `ensure_system_npm()` function (lines 1777-1870)

**Problem:** The function temporarily modifies the global `PATH` variable to check for system npm, which can cause race conditions with concurrent operations.

**Fix:** Use explicit path resolution with `PATH="$base_path" command -v npm` instead of modifying the global PATH.

**Impact:** Eliminates race conditions and makes PATH handling more explicit and safe.

---

### 4. BUG-001: Array indexing for dynamic npm

**Severity:** High
**Location:** `initialize_tools()` function (lines 912-950)

**Problem:** When npm is dynamically added to the tool list, it becomes index 0, but the cache arrays might not have the correct size, causing potential index-out-of-bounds errors.

**Fix:** After `prefetch_latest_versions`, ensure the cache array size matches the tool array size by expanding it if needed.

**Impact:** Prevents index-out-of-bounds crashes when npm is dynamically added.

---

### 5. PERF-001: GitHub API rate limit handling

**Severity:** Medium
**Location:** `github_api_get_with_retry()` function (lines 376-413)

**Problem:** The script doesn't properly handle GitHub API rate limits - it checks for 403 errors but doesn't calculate proper wait times based on the rate limit reset timestamp.

**Fix:**
- Calculate actual wait time from `GITHUB_RATE_LIMIT_RESET` timestamp
- Use exponential backoff for retries
- Reduce max retries from 5 to 3 to fail faster
- Increase initial retry delay from 1s to 2s

**Impact:** Better API behavior with intelligent wait times and proper exponential backoff.

---

## Files Created

1. **PERFORMANCE_FIXES.md** - Detailed documentation of each issue with code examples
2. **performance_fixes.patch** - Unified diff patch for manual application
3. **fix_performance_issues.sh** - Automated fix script (complex)
4. **apply_simple_fixes.sh** - Simple automated fix for PERF-003

## How to Apply Fixes

### Option 1: Manual Application (Recommended)

Review the changes in `PERFORMANCE_FIXES.md` and apply them manually to understand each fix.

### Option 2: Patch Application

```bash
# Apply the patch
patch -p1 < performance_fixes.patch

# Verify syntax
bash -n install_coding_tools.sh
```

### Option 3: Automated Script

```bash
# Run the fix script
chmod +x fix_performance_issues.sh
./fix_performance_issues.sh
```

## Testing

After applying fixes:

```bash
# 1. Syntax check
bash -n install_coding_tools.sh

# 2. Help check
./install_coding_tools.sh --help

# 3. Dry run test
./install_coding_tools.sh --yes
```

## Summary Table

| Issue ID | Severity | Type | Impact | Fix Complexity |
|----------|----------|------|--------|----------------|
| PERF-002 | Medium | Performance | User experience improvement | Low |
| PERF-003 | High | Performance | Significant performance improvement | Low |
| LOG-002 | High | Reliability | Prevents race conditions | Medium |
| BUG-001 | High | Correctness | Prevents crashes | Low |
| PERF-001 | Medium | Performance | Better API behavior | Medium |

## Backward Compatibility

All fixes are backward compatible and don't change the script's external behavior or API. The fixes only improve internal implementation.

## Related Issues

These fixes address issues commonly found in shell scripts that:
- Make multiple subprocess calls for the same data
- Modify global state (PATH) temporarily
- Use arrays without proper size validation
- Interact with rate-limited APIs without proper backoff

## Additional Recommendations

1. **Add unit tests** for the caching functions to ensure they work correctly
2. **Add integration tests** for the version fetching logic
3. **Consider using a configuration file** for cache timeouts and retry settings
4. **Add logging** for cache hits/misses to monitor performance improvements
