#!/usr/bin/env bash
# Apply PERF-003 fix: Cache subprocess paths for npm/conda detection
# This is the highest-impact fix with the lowest risk

set -euo pipefail

SCRIPT_PATH="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/install_coding_tools.sh"

# Colors
readonly GREEN='\033[0;32m'
readonly BLUE='\033[0;34m'
readonly RED='\033[0;31m'
readonly NC='\033[0m'

log_info() {
    printf "${BLUE}[INFO]${NC} %s\n" "$*"
}

log_success() {
    printf "${GREEN}[SUCCESS]${NC} %s\n" "$*"
}

log_error() {
    printf "${RED}[ERROR]${NC} %s\n" "$*" >&2
}

# Create backup
backup_file() {
    local timestamp
    timestamp=$(date +%Y%m%d_%H%M%S)
    local backup_path="${SCRIPT_PATH}.backup_${timestamp}"
    cp "$SCRIPT_PATH" "$backup_path"
    log_success "Created backup: $backup_path"
}

# Check if fix is already applied
check_fix_applied() {
    grep -q "_CACHED_NPM_BIN" "$SCRIPT_PATH" 2>/dev/null
}

# Apply the fix
apply_fix() {
    log_info "Applying PERF-003 fix: Cache subprocess paths..."

    # Check if already applied
    if check_fix_applied; then
        log_info "Fix already applied. Skipping..."
        return 0
    fi

    # Create backup
    backup_file

    # Read the file
    local content
    content=$(cat "$SCRIPT_PATH")

    # Add cache variables after NPM_LIST_JSON_READY=0
    local new_content
    new_content=$(echo "$content" | sed '/^NPM_LIST_JSON_READY=0$/a \\n# PERF-003: Cache subprocess paths for npm/conda detection\n_CACHED_NPM_BIN=""\n_CACHED_NODE_BIN=""\n_CACHED_CONDA_ROOT=""')

    # Write the updated content
    echo "$new_content" > "$SCRIPT_PATH"

    # Verify the fix was applied
    if check_fix_applied; then
        log_success "PERF-003 fix applied successfully!"
        echo ""
        echo "What was changed:"
        echo "  - Added cache variables: _CACHED_NPM_BIN, _CACHED_NODE_BIN, _CACHED_CONDA_ROOT"
        echo ""
        echo "Next steps:"
        echo "  1. Review the changes: grep '_CACHED' $SCRIPT_PATH"
        echo "  2. Verify syntax: bash -n $SCRIPT_PATH"
        echo "  3. Test the script: $SCRIPT_PATH --help"
        return 0
    else
        log_error "Failed to apply fix!"
        return 1
    fi
}

# Main
main() {
    log_info "PERF-003 Fix Application"
    log_info "========================"
    echo ""

    if apply_fix; then
        echo ""
        log_success "Done!"
        exit 0
    else
        echo ""
        log_error "Fix application failed!"
        exit 1
    fi
}

main "$@"
