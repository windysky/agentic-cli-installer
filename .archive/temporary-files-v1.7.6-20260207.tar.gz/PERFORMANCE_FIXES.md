# Performance and Logic Issues - Fix Documentation

This document describes the performance and logic issues identified in `install_coding_tools.sh` and provides fixes for each.

## Issues and Fixes

### PERF-002: Stream version fetch results instead of waiting for all

**Location:** `prefetch_latest_versions()` function (lines 836-906)

**Issue:** The current implementation waits for all subprocesses to complete before processing any results. This delays showing progress to the user.

**Current Code:**
```bash
for i in "${!pids[@]}"; do
    local pid="${pids[$i]}"
    if ! wait "$pid"; then
        log_warning "Failed to fetch version for tool ${TOOL_NAMES[$i]}"
        failed_count=$((failed_count + 1))
    fi
done

# Only after ALL subprocesses complete, process results
for i in "${!TOOL_NAMES[@]}"; do
    local out="${tmp_dir}/${i}"
    if [[ -f "$out" ]]; then
        LATEST_VERSION_CACHE[$i]=$(<"$out")
    else
        LATEST_VERSION_CACHE[$i]=""
    fi
done
```

**Fix:** Process each result as soon as its subprocess completes:

```bash
# Process results as they complete instead of waiting for all
for i in "${!pids[@]}"; do
    local pid="${pids[$i]}"
    if wait "$pid"; then
        local out="${tmp_dir}/${i}"
        if [[ -f "$out" ]]; then
            LATEST_VERSION_CACHE[$i]=$(<"$out")
        fi
    else
        log_warning "Failed to fetch version for tool ${TOOL_NAMES[$i]}"
        failed_count=$((failed_count + 1))
    fi
done
```

**Impact:** Users see version information earlier as results stream in.

---

### PERF-003: Cache subprocess paths for npm/conda detection

**Location:** Global variables section (after line 88)

**Issue:** Functions like `get_conda_root()`, `get_npm_bin()`, and `get_npm_node_bin()` are called multiple times but don't cache their results. This causes redundant subprocess calls.

**Fix:** Add cache variables and update functions to use them:

**Step 1:** Add cache variables after `NPM_LIST_JSON_READY=0`:
```bash
# PERF-003: Cache subprocess paths for npm/conda detection
_CACHED_NPM_BIN=""
_CACHED_NODE_BIN=""
_CACHED_CONDA_ROOT=""
```

**Step 2:** Update `get_conda_root()` to use cache:
```bash
get_conda_root() {
    # PERF-003: Use cached value if available
    if [[ -n "$_CACHED_CONDA_ROOT" ]]; then
        printf "%s" "$_CACHED_CONDA_ROOT"
        return 0
    fi

    local conda_root=""
    if command -v conda >/dev/null 2>&1; then
        conda_root=$(conda info --base 2>/dev/null || true)
    fi

    # Fallback: Try to detect from common paths if conda command fails
    if [[ -z "$conda_root" ]]; then
        local conda_fallbacks=(
            "$HOME/miniconda3"
            "$HOME/anaconda3"
            "/opt/miniconda3"
            "/opt/anaconda3"
            "/usr/local/miniconda3"
            "/usr/local/anaconda3"
        )
        for path in "${conda_fallbacks[@]}"; do
            if [[ -d "$path" ]]; then
                conda_root="$path"
                break
            fi
        done
    fi

    # Cache the result
    if [[ -n "$conda_root" ]]; then
        _CACHED_CONDA_ROOT="$conda_root"
        printf "%s" "$conda_root"
        return 0
    fi
    return 1
}
```

**Step 3:** Update `get_npm_bin()` to use cache:
```bash
get_npm_bin() {
    # PERF-003: Use cached value if available
    if [[ -n "$_CACHED_NPM_BIN" && -x "$_CACHED_NPM_BIN" ]]; then
        printf "%s" "$_CACHED_NPM_BIN"
        return 0
    fi

    local npm_path
    npm_path=$(get_conda_npm_path || true)
    if [[ -n "$npm_path" && -x "$npm_path" ]]; then
        # Cache the result
        _CACHED_NPM_BIN="$npm_path"
        printf "%s" "$npm_path"
        return 0
    fi
    return 1
}
```

**Step 4:** Update `get_npm_node_bin()` to use cache:
```bash
get_npm_node_bin() {
    # PERF-003: Use cached value if available
    if [[ -n "$_CACHED_NODE_BIN" && -x "$_CACHED_NODE_BIN" ]]; then
        printf "%s" "$_CACHED_NODE_BIN"
        return 0
    fi

    local npm_bin
    npm_bin=$(get_npm_bin) || return 1
    local node_bin
    node_bin="$(dirname "$npm_bin")/node"
    if [[ -x "$node_bin" ]]; then
        # Cache the result
        _CACHED_NODE_BIN="$node_bin"
        printf "%s" "$node_bin"
        return 0
    fi
    return 1
}
```

**Impact:** Eliminates redundant subprocess calls, improving performance.

---

### LOG-002: Fix PATH race condition with explicit path resolution

**Location:** `ensure_system_npm()` function (lines 1777-1870)

**Issue:** The function temporarily modifies `PATH` which can cause race conditions with other concurrent operations. The PATH is changed to check for system npm, then restored, but there's a window where the wrong npm might be found.

**Current Code:**
```bash
# Prefer system locations by temporarily removing conda from PATH
PATH="$base_path"
if command -v npm >/dev/null 2>&1; then
    system_npm_path=$(command -v npm)
    npm_version=$(npm --version 2>/dev/null | head -n1 || true)
fi
PATH="$original_path"
```

**Fix:** Use explicit path resolution instead of modifying global PATH:

```bash
# LOG-002: Use explicit path resolution to avoid race conditions
local base_path="/usr/local/bin:/usr/bin:/bin:/usr/local/sbin:/usr/sbin:/sbin:/opt/homebrew/bin:/opt/local/bin"
local original_path="$PATH"
local system_npm_path=""
local npm_version=""

# Use command -v with explicit PATH to avoid race conditions
system_npm_path=$(PATH="$base_path" command -v npm 2>/dev/null || true)

if [[ -n "$system_npm_path" ]]; then
    npm_version=$("$system_npm_path" --version 2>/dev/null | head -n1 || true)
fi
```

**Also update the `install_system_npm()` inner function:**

```bash
if curl -q https://www.npmjs.com/install.sh 2>/dev/null | sudo bash; then
    # Use explicit path resolution after installation
    system_npm_path=$(PATH="$base_path:$original_path" command -v npm 2>/dev/null || true)
    if [[ -n "$system_npm_path" ]]; then
        npm_version=$("$system_npm_path" --version 2>/dev/null | head -n1 || true)
    fi
    # ... rest of function
fi
```

**Impact:** Eliminates race conditions and makes PATH handling more explicit and safe.

---

### BUG-001: Fix array indexing when npm tool is dynamically added

**Location:** `initialize_tools()` function (lines 912-950)

**Issue:** When npm is dynamically added to the tool list (lines 914-920), it becomes index 0 in the arrays. However, the `prefetch_latest_versions` function creates files using tool index (`${tmp_dir}/${i}`), and if npm was added dynamically, the cache arrays might not have the correct size.

**Current Code:**
```bash
initialize_tools() {
    # Conditionally add npm to the tool list (only if detected)
    if get_npm_bin >/dev/null 2>&1; then
        TOOL_NAMES+=("npm")
        TOOL_MANAGERS+=("npm-self")
        TOOL_PACKAGES+=("npm")
        TOOL_DESCRIPTIONS+=("npm (Node Package Manager)")
        UPDATE_ONLY+=(1)  # npm is update-only
    fi

    # Add regular tools
    for tool_info in "${TOOLS[@]}"; do
        # ... add tools
    done

    prefetch_latest_versions

    for i in "${!TOOL_NAMES[@]}"; do
        # ... uses LATEST_VERSION_CACHE[$i]
    done
}
```

**Fix:** Ensure cache array is properly sized after prefetch:

```bash
initialize_tools() {
    # BUG-001: When adding npm dynamically, ensure cache arrays are properly sized
    # npm is added first (index 0), so cache arrays must account for this
    if get_npm_bin >/dev/null 2>&1; then
        TOOL_NAMES+=("npm")
        TOOL_MANAGERS+=("npm-self")
        TOOL_PACKAGES+=("npm")
        TOOL_DESCRIPTIONS+=("npm (Node Package Manager)")
        UPDATE_ONLY+=(1)  # npm is update-only
    fi

    # Add regular tools
    for tool_info in "${TOOLS[@]}"; do
        IFS='|' read -r name manager pkg description <<< "$tool_info"
        TOOL_NAMES+=("$name")
        TOOL_MANAGERS+=("$manager")
        TOOL_PACKAGES+=("$pkg")
        TOOL_DESCRIPTIONS+=("$description")
        UPDATE_ONLY+=(0)
    done

    prefetch_latest_versions

    # BUG-001: Ensure cache array matches tool array size
    # (handles case where npm was dynamically added)
    local expected_size=${#TOOL_NAMES[@]}
    local cache_size=${#LATEST_VERSION_CACHE[@]}
    if [[ $cache_size -lt $expected_size ]]; then
        for ((i=cache_size; i<expected_size; i++)); do
            LATEST_VERSION_CACHE[i]=""
        done
    fi

    # Continue with rest of function...
}
```

**Impact:** Prevents index-out-of-bounds errors when npm is dynamically added.

---

### PERF-001: Improve GitHub API rate limit handling

**Location:** `github_api_get_with_retry()` function (lines 376-413)

**Issue:** The current implementation doesn't properly handle GitHub API rate limits. It checks for 403 errors but doesn't use exponential backoff or calculate proper wait times based on the rate limit reset timestamp.

**Current Code:**
```bash
github_api_get_with_retry() {
    local url=$1
    local max_retries=5
    local retry_delay=1

    for attempt in $(seq 1 $max_retries); do
        # ... make request

        # Handle rate limiting
        if [[ "$http_code" == "403" ]] && [[ "$GITHUB_RATE_LIMIT_REMAINING" -lt 5 ]]; then
            if [[ $attempt -lt $max_retries ]]; then
                log_warning "GitHub API rate limit low ($GITHUB_RATE_LIMIT_REMAINING remaining). Retrying in ${retry_delay}s..."
                sleep "$retry_delay"
                retry_delay=$((retry_delay * 2))
                continue
            else
                log_error "GitHub API rate limit exceeded. Please try again later."
                return 1
            fi
        fi
        # ...
    done
}
```

**Fix:** Implement proper exponential backoff and wait for rate limit reset:

```bash
github_api_get_with_retry() {
    local url=$1
    local max_retries=3  # PERF-001: Reduced from 5 to fail faster on rate limits
    local retry_delay=2   # PERF-001: Increased from 1 for longer backoff

    for attempt in $(seq 1 $max_retries); do
        local response
        local http_code

        # Make request with headers captured
        response=$(curl -fsSL -i --max-time 10 "$url" 2>/dev/null)
        http_code=$(echo "$response" | grep -i "^HTTP/" | awk '{print $2}')

        # Check rate limit from headers
        check_github_rate_limit "$response"

        # PERF-001: Better rate limit handling with exponential backoff
        if [[ "$http_code" == "403" ]]; then
            if [[ "$GITHUB_RATE_LIMIT_REMAINING" -lt 10 ]]; then
                local wait_time=$((GITHUB_RATE_LIMIT_RESET - $(date +%s) + 5))
                if [[ $wait_time -gt 0 ]] && [[ $attempt -lt $max_retries ]]; then
                    log_warning "GitHub API rate limit exceeded. Waiting ${wait_time}s for reset..."
                    sleep "$wait_time"
                    continue
                else
                    log_error "GitHub API rate limit exceeded. Please try again after ${wait_time}s."
                    return 1
                fi
            fi
        fi

        # Check for successful response
        if [[ "$http_code" == "200" ]]; then
            # Extract body and return
            local body
            body=$(echo "$response" | sed -n '/^{/,$p')
            echo "$body"
            return 0
        fi

        # Retry on other errors with exponential backoff
        if [[ $attempt -lt $max_retries ]]; then
            log_warning "GitHub API request failed (HTTP $http_code). Retrying in ${retry_delay}s..."
            sleep "$retry_delay"
            retry_delay=$((retry_delay * 2))  # Exponential backoff
        fi
    done

    log_error "Failed to fetch from GitHub API after $max_retries attempts"
    return 1
}
```

**Impact:** Better rate limit handling with intelligent wait times and exponential backoff.

---

## Testing

After applying fixes, test the script:

```bash
# Syntax check
bash -n install_coding_tools.sh

# Dry run (if supported)
./install_coding_tools.sh --help

# Interactive test
./install_coding_tools.sh
```

---

## Summary

| Issue | Severity | Impact | Fix Complexity |
|-------|----------|--------|----------------|
| PERF-002 | Medium | User experience improvement | Low |
| PERF-003 | High | Significant performance improvement | Low |
| LOG-002 | High | Prevents race conditions | Medium |
| BUG-001 | High | Prevents crashes | Low |
| PERF-001 | Medium | Better API behavior | Medium |

All fixes are backward compatible and don't change the script's external behavior.
