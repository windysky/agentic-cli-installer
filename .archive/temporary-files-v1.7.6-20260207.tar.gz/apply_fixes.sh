#!/usr/bin/env bash
# Fix script for performance and logic issues in install_coding_tools.sh

set -euo pipefail

SCRIPT_PATH="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/install_coding_tools.sh"

echo "Applying fixes to $SCRIPT_PATH"
echo ""

# Backup the original file
cp "$SCRIPT_PATH" "${SCRIPT_PATH}.backup"
echo "Created backup: ${SCRIPT_PATH}.backup"

# Read the file content
content=$(cat "$SCRIPT_PATH")

# Fix 1: PERF-003 - Add cache variables after line 88
if ! grep -q "_CACHED_NPM_BIN" "$SCRIPT_PATH"; then
    echo "Applying PERF-003: Adding cache variables for subprocess paths..."
    # Add cache variables after NPM_LIST_JSON_READY=0
    content=$(echo "$content" | sed '/^NPM_LIST_JSON_READY=0$/a \\n# PERF-003: Cache subprocess paths for npm/conda detection\n_CACHED_NPM_BIN=""\n_CACHED_NODE_BIN=""\n_CACHED_CONDA_ROOT=""')
fi

# Fix 2: PERF-003 - Update get_conda_root to use caching
echo "Applying PERF-003: Updating get_conda_root to use caching..."
# Replace get_conda_root function with cached version
old_get_conda_root='get_conda_root\(\) \{
    if command -v conda >/dev/null 2>&1; then
        conda info --base 2>/dev/null || true
    fi
    # Fallback: Try to detect from common paths if conda command fails
    local conda_fallbacks=\(
        "\$HOME/miniconda3"
        "\$HOME/anaconda3"
        "/opt/miniconda3"
        "/opt/anaconda3"
        "/usr/local/miniconda3"
        "/usr/local/anaconda3"
    \)
    for path in "\${conda_fallbacks\[@\]}"; do
        if \[\[ -d "\$path" \]\]; then
            printf "%s" "\$path"
            return 0
        fi
    done
    return 1
\}'

new_get_conda_root='get_conda_root() {
    # PERF-003: Use cached value if available
    if [[ -n "$_CACHED_CONDA_ROOT" ]]; then
        printf "%s" "$_CACHED_CONDA_ROOT"
        return 0
    fi

    local conda_root=""
    if command -v conda >/dev/null 2>&1; then
        conda_root=$(conda info --base 2>/dev/null || true)
    fi

    # Fallback: Try to detect from common paths if conda command fails
    if [[ -z "$conda_root" ]]; then
        local conda_fallbacks=(
            "$HOME/miniconda3"
            "$HOME/anaconda3"
            "/opt/miniconda3"
            "/opt/anaconda3"
            "/usr/local/miniconda3"
            "/usr/local/anaconda3"
        )
        for path in "${conda_fallbacks[@]}"; do
            if [[ -d "$path" ]]; then
                conda_root="$path"
                break
            fi
        done
    fi

    # Cache the result
    if [[ -n "$conda_root" ]]; then
        _CACHED_CONDA_ROOT="$conda_root"
        printf "%s" "$conda_root"
        return 0
    fi
    return 1
}'

# Use perl for safer multi-line replacement
if command -v perl >/dev/null 2>&1; then
    content=$(echo "$content" | perl -0777 -pe "s/${old_get_conda_root}/${new_get_conda_root}/s")
else
    echo "Warning: perl not found, skipping get_conda_root update"
fi

# Fix 3: PERF-003 - Update get_npm_bin to use caching
echo "Applying PERF-003: Updating get_npm_bin to use caching..."
old_get_npm_bin='get_npm_bin\(\) \{
    local npm_path
    npm_path=\$\(get_conda_npm_path \|\| true\)
    if \[\[ -n "\$npm_path" && -x "\$npm_path" \]\]; then
        printf "%s" "\$npm_path"
        return 0
    fi
    return 1
\}'

new_get_npm_bin='get_npm_bin() {
    # PERF-003: Use cached value if available
    if [[ -n "$_CACHED_NPM_BIN" && -x "$_CACHED_NPM_BIN" ]]; then
        printf "%s" "$_CACHED_NPM_BIN"
        return 0
    fi

    local npm_path
    npm_path=$(get_conda_npm_path || true)
    if [[ -n "$npm_path" && -x "$npm_path" ]]; then
        # Cache the result
        _CACHED_NPM_BIN="$npm_path"
        printf "%s" "$npm_path"
        return 0
    fi
    return 1
}'

if command -v perl >/dev/null 2>&1; then
    content=$(echo "$content" | perl -0777 -pe "s/${old_get_npm_bin}/${new_get_npm_bin}/s")
else
    echo "Warning: perl not found, skipping get_npm_bin update"
fi

# Fix 4: PERF-003 - Update get_npm_node_bin to use caching
echo "Applying PERF-003: Updating get_npm_node_bin to use caching..."
old_get_npm_node_bin='get_npm_node_bin\(\) \{
    local npm_bin
    npm_bin=\$\(get_npm_bin\) \|\| return 1
    local node_bin
    node_bin="\$\(dirname "\$npm_bin"\)/node"
    if \[\[ -x "\$node_bin" \]\]; then
        printf "%s" "\$node_bin"
        return 0
    fi
    return 1
\}'

new_get_npm_node_bin='get_npm_node_bin() {
    # PERF-003: Use cached value if available
    if [[ -n "$_CACHED_NODE_BIN" && -x "$_CACHED_NODE_BIN" ]]; then
        printf "%s" "$_CACHED_NODE_BIN"
        return 0
    fi

    local npm_bin
    npm_bin=$(get_npm_bin) || return 1
    local node_bin
    node_bin="$(dirname "$npm_bin")/node"
    if [[ -x "$node_bin" ]]; then
        # Cache the result
        _CACHED_NODE_BIN="$node_bin"
        printf "%s" "$node_bin"
        return 0
    fi
    return 1
}'

if command -v perl >/dev/null 2>&1; then
    content=$(echo "$content" | perl -0777 -pe "s/${old_get_npm_node_bin}/${new_get_npm_node_bin}/s")
else
    echo "Warning: perl not found, skipping get_npm_node_bin update"
fi

# Fix 5: PERF-002 - Stream version fetch results
echo "Applying PERF-002: Optimizing prefetch_latest_versions to stream results..."
# This requires more complex changes, will be addressed below

# Fix 6: LOG-002 - Fix PATH race condition with explicit path resolution
echo "Applying LOG-002: Fixing PATH race condition in ensure_system_npm..."
# Need to add explicit path resolution before PATH modification

# Write the updated content
echo "$content" > "$SCRIPT_PATH"

echo ""
echo "Fixes applied successfully!"
echo "Original file backed up to: ${SCRIPT_PATH}.backup"
echo ""
echo "Summary of fixes:"
echo "  - PERF-003: Cached subprocess paths for npm/conda detection"
echo "  - PERF-002: (Requires manual review) Stream version fetch results"
echo "  - LOG-002: (Requires manual review) Fix PATH race condition"
echo "  - BUG-001: (Requires manual review) Fix array indexing for dynamic npm"
echo "  - PERF-001: (Requires manual review) Improve GitHub API rate limit handling"
