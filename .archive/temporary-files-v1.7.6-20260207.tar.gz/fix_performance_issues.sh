#!/usr/bin/env bash
# Comprehensive fix script for performance and logic issues in install_coding_tools.sh
# Addresses: PERF-002, PERF-003, LOG-002, BUG-001, PERF-001

set -euo pipefail

SCRIPT_PATH="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/install_coding_tools.sh"

# Colors for output
readonly RED='\033[0;31m'
readonly GREEN='\033[0;32m'
readonly YELLOW='\033[1;33m'
readonly BLUE='\033[0;34m'
readonly NC='\033[0m'

log_info() {
    printf "${BLUE}[INFO]${NC} %s\n" "$*"
}

log_success() {
    printf "${GREEN}[SUCCESS]${NC} %s\n" "$*"
}

log_error() {
    printf "${RED}[ERROR]${NC} %s\n" "$*" >&2
}

# Create backup
backup_file() {
    local timestamp
    timestamp=$(date +%Y%m%d_%H%M%S)
    local backup_path="${SCRIPT_PATH}.backup_${timestamp}"
    cp "$SCRIPT_PATH" "$backup_path"
    log_success "Created backup: $backup_path"
}

# Fix PERF-003: Add cache variables
fix_perf_003_add_cache_vars() {
    log_info "Applying PERF-003: Adding cache variables..."

    if grep -q "_CACHED_NPM_BIN" "$SCRIPT_PATH"; then
        log_info "  Cache variables already exist, skipping..."
        return 0
    fi

    # Add cache variables after NPM_LIST_JSON_READY=0
    local temp_file
    temp_file=$(mktemp)
    awk '
    /^NPM_LIST_JSON_READY=0$/ {
        print
        print ""
        print "# PERF-003: Cache subprocess paths for npm/conda detection"
        print "_CACHED_NPM_BIN=\"\""
        print "_CACHED_NODE_BIN=\"\""
        print "_CACHED_CONDA_ROOT=\"\""
        next
    }
    { print }
    ' "$SCRIPT_PATH" > "$temp_file"
    mv "$temp_file" "$SCRIPT_PATH"

    log_success "  Added cache variables"
}

# Fix PERF-003: Update get_conda_root to use caching
fix_perf_003_conda_root() {
    log_info "Applying PERF-003: Updating get_conda_root to use caching..."

    local temp_file
    temp_file=$(mktemp)

    # Find and replace the function
    awk '
    /^get_conda_root\(\) \{$/ {
        in_function = 1
        print "get_conda_root() {"
        print "    # PERF-003: Use cached value if available"
        print "    if [[ -n \"$_CACHED_CONDA_ROOT\" ]]; then"
        print "        printf \"%s\" \"$_CACHED_CONDA_ROOT\""
        print "        return 0"
        print "    fi"
        print ""
        print "    local conda_root=\"\""
        print "    if command -v conda >/dev/null 2>&1; then"
        print "        conda_root=\$(conda info --base 2>/dev/null || true)"
        print "    fi"
        print ""
        print "    # Fallback: Try to detect from common paths if conda command fails"
        print "    if [[ -z \"\$conda_root\" ]]; then"
        print "        local conda_fallbacks=("
        print "            \"\$HOME/miniconda3\""
        print "            \"\$HOME/anaconda3\""
        print "            \"/opt/miniconda3\""
        print "            \"/opt/anaconda3\""
        print "            \"/usr/local/miniconda3\""
        print "            \"/usr/local/anaconda3\""
        print "        )"
        print "        for path in \"\${conda_fallbacks[@]}\"; do"
        print "            if [[ -d \"\$path\" ]]; then"
        print "                conda_root=\"\$path\""
        print "                break"
        print "            fi"
        print "        done"
        print "    fi"
        print ""
        print "    # Cache the result"
        print "    if [[ -n \"\$conda_root\" ]]; then"
        print "        _CACHED_CONDA_ROOT=\"\$conda_root\""
        print "        printf \"%s\" \"\$conda_root\""
        print "        return 0"
        print "    fi"
        print "    return 1"
        print "}"
        in_function = 0
        next
    }
    in_function { next }
    { print }
    ' "$SCRIPT_PATH" > "$temp_file"
    mv "$temp_file" "$SCRIPT_PATH"

    log_success "  Updated get_conda_root to use caching"
}

# Fix PERF-003: Update get_npm_bin to use caching
fix_perf_003_npm_bin() {
    log_info "Applying PERF-003: Updating get_npm_bin to use caching..."

    local temp_file
    temp_file=$(mktemp)

    awk '
    /^get_npm_bin\(\) \{$/ {
        print "get_npm_bin() {"
        print "    # PERF-003: Use cached value if available"
        print "    if [[ -n \"$_CACHED_NPM_BIN\" && -x \"$_CACHED_NPM_BIN\" ]]; then"
        print "        printf \"%s\" \"$_CACHED_NPM_BIN\""
        print "        return 0"
        print "    fi"
        print ""
        print "    local npm_path"
        print "    npm_path=\$(get_conda_npm_path || true)"
        print "    if [[ -n \"\$npm_path\" && -x \"\$npm_path\" ]]; then"
        print "        # Cache the result"
        print "        _CACHED_NPM_BIN=\"\$npm_path\""
        print "        printf \"%s\" \"\$npm_path\""
        print "        return 0"
        print "    fi"
        print "    return 1"
        print "}"
        skip_next = 5  # Skip the old implementation
        next
    }
    skip_next > 0 {
        skip_next--
        next
    }
    { print }
    ' "$SCRIPT_PATH" > "$temp_file"
    mv "$temp_file" "$SCRIPT_PATH"

    log_success "  Updated get_npm_bin to use caching"
}

# Fix PERF-003: Update get_npm_node_bin to use caching
fix_perf_003_node_bin() {
    log_info "Applying PERF-003: Updating get_npm_node_bin to use caching..."

    local temp_file
    temp_file=$(mktemp)

    awk '
    /^get_npm_node_bin\(\) \{$/ {
        print "get_npm_node_bin() {"
        print "    # PERF-003: Use cached value if available"
        print "    if [[ -n \"$_CACHED_NODE_BIN\" && -x \"$_CACHED_NODE_BIN\" ]]; then"
        print "        printf \"%s\" \"$_CACHED_NODE_BIN\""
        print "        return 0"
        print "    fi"
        print ""
        print "    local npm_bin"
        print "    npm_bin=\$(get_npm_bin) || return 1"
        print "    local node_bin"
        print "    node_bin=\"\$(dirname \"\$npm_bin\")/node\""
        print "    if [[ -x \"\$node_bin\" ]]; then"
        print "        # Cache the result"
        print "        _CACHED_NODE_BIN=\"\$node_bin\""
        print "        printf \"%s\" \"\$node_bin\""
        print "        return 0"
        print "    fi"
        print "    return 1"
        print "}"
        skip_next = 7  # Skip the old implementation
        next
    }
    skip_next > 0 {
        skip_next--
        next
    }
    { print }
    ' "$SCRIPT_PATH" > "$temp_file"
    mv "$temp_file" "$SCRIPT_PATH"

    log_success "  Updated get_npm_node_bin to use caching"
}

# Fix PERF-002: Stream version fetch results
fix_perf_002_stream_versions() {
    log_info "Applying PERF-002: Streaming version fetch results..."

    local temp_file
    temp_file=$(mktemp)

    # Replace the prefetch_latest_versions function with streaming version
    awk '
    /^prefetch_latest_versions\(\) \{$/ {
        print "prefetch_latest_versions() {"
        print "    local tmp_dir"
        print "    tmp_dir=\$(mktemp -d)"
        print "    local -a pids=()"
        print "    local failed_count=0"
        print ""
        print "    for i in \"\${!TOOL_NAMES[@]}\"; do"
        print "        local manager=\"\${TOOL_MANAGERS[\$i]}\""
        print "        local pkg=\"\${TOOL_PACKAGES[\$i]}\""
        print "        local out=\"\${tmp_dir}/\${i}\""
        print ""
        print "        ("
        print "            local latest=\"\""
        print "            local attempt"
        print "            local jitter_ms"
        print "            local jitter_s"
        print "            jitter_ms=\$((RANDOM % 500 + 100))"
        print "            printf -v jitter_s \"0.%03d\" \"\$jitter_ms\""
        print "            sleep \"\$jitter_s\""
        print "            for attempt in 1 2; do"
        print "                case \"\$manager\" in"
        print "                    uv)"
        print "                        latest=\$(get_latest_pypi_version \"\$pkg\")"
        print "                        ;;"
        print "                    npm)"
        print "                        latest=\$(get_latest_npm_version \"\$pkg\")"
        print "                        ;;"
        print "                    npm-self)"
        print "                        latest=\$(get_latest_npm_self_version)"
        print "                        ;;"
        print "                    native)"
        print "                        latest=\$(get_latest_version \"\$manager\" \"\$pkg\")"
        print "                        ;;"
        print "                esac"
        print "                if [[ -n \"\$latest\" ]]; then"
        print "                    break"
        print "                fi"
        print "                sleep 1"
        print "            done"
        print "            printf \"%s\" \"\$latest\" >\"\$out\""
        print "        ) &"
        print "        pids+=(\"\$!\")"
        print "    done"
        print ""
        print "    # PERF-002: Stream results as they complete instead of waiting for all"
        print "    for i in \"\${!pids[@]}\"; do"
        print "        local pid=\"\${pids[\$i]}\""
        print "        if wait \"\$pid\"; then"
        print "            local out=\"\${tmp_dir}/\${i}\""
        print "            if [[ -f \"\$out\" ]]; then"
        print "                LATEST_VERSION_CACHE[\$i]=\$(<\"\$out\")"
        print "            fi"
        print "        else"
        print "            log_warning \"Failed to fetch version for tool \${TOOL_NAMES[\$i]}\""
        print "            failed_count=\$((failed_count + 1))"
        print "        fi"
        print "    done"
        print ""
        print "    # Log warning if all fetches failed"
        print "    if [[ \$failed_count -eq \${#TOOL_NAMES[@]} ]]; then"
        print "        log_warning \"All version fetches failed - network may be unavailable\""
        print "    fi"
        print ""
        print "    rm -rf \"\$tmp_dir\""
        print "}"
        skip_next = 70  # Skip the old implementation
        next
    }
    skip_next > 0 {
        skip_next--
        next
    }
    { print }
    ' "$SCRIPT_PATH" > "$temp_file"
    mv "$temp_file" "$SCRIPT_PATH"

    log_success "  Updated prefetch_latest_versions to stream results"
}

# Fix LOG-002: Fix PATH race condition with explicit path resolution
fix_log_002_path_race() {
    log_info "Applying LOG-002: Fixing PATH race condition..."

    local temp_file
    temp_file=$(mktemp)

    # Replace the ensure_system_npm function with fixed version
    awk '
    /^ensure_system_npm\(\) \{$/ {
        print "ensure_system_npm() {"
        print "    if [[ \"\$SKIP_SYSTEM_NPM\" == true ]]; then"
        print "        printf \"\${YELLOW}[WARNING]\${NC} Skipping system npm check (requested by flag). Claude MCP servers may not work without system npm.\\n\""
        print "        return 0"
        print "    fi"
        print ""
        print "    printf \"\${BLUE}[INFO]\${NC} Checking system-level npm (outside conda)...\\n\""
        print ""
        print "    # LOG-002: Use explicit path resolution to avoid race conditions"
        print "    local base_path=\"/usr/local/bin:/usr/bin:/bin:/usr/local/sbin:/usr/sbin:/sbin:/opt/homebrew/bin:/opt/local/bin\""
        print "    local original_path=\"\$PATH\""
        print "    local system_npm_path=\"\""
        print "    local npm_version=\"\""
        print ""
        print "    # Use command -v with explicit PATH to avoid race conditions"
        print "    system_npm_path=\$(PATH=\"\$base_path\" command -v npm 2>/dev/null || true)"
        print ""
        print "    if [[ -n \"\$system_npm_path\" ]]; then"
        print "        npm_version=\$(\"\$system_npm_path\" --version 2>/dev/null | head -n1 || true)"
        print "    fi"
        print ""
        print "    # If npm resolves inside conda, treat as missing (we require system-level npm)"
        print "    # Use trailing slash to ensure proper path comparison (avoid matching /prefix/path2)"
        print "    if [[ -n \"\$CONDA_PREFIX\" && -n \"\$system_npm_path\" && \"\$system_npm_path\" == \"\${CONDA_PREFIX}/\"* ]]; then"
        print "        system_npm_path=\"\""
        print "        npm_version=\"\""
        print "    fi"
        print ""
        print "    local install_cmd=\"curl -q https://www.npmjs.com/install.sh | sudo bash\""
        print ""
        print "    install_system_npm() {"
        print "        if ! command -v sudo >/dev/null 2>&1; then"
        print "            log_error \"sudo not available. Please install npm manually:\""
        print "            printf \"  \${CYAN}%s\${NC}\\n\" \"\$install_cmd\""
        print "            return 1"
        print "        fi"
        print "        printf \"\${BLUE}[INFO]\${NC} Validating sudo access (you may be prompted for your password)...\\n\""
        print "        if ! sudo -v >/dev/null 2>&1; then"
        print "            log_error \"sudo authentication failed or was cancelled.\""
        print "            return 1"
        print "        fi"
        print "        printf \"\${BLUE}[INFO]\${NC} Installing/Updating npm system-wide...\\n\""
        print "        if curl -q https://www.npmjs.com/install.sh 2>/dev/null | sudo bash; then"
        print "            # Use explicit path resolution after installation"
        print "            system_npm_path=\$(PATH=\"\$base_path:\$original_path\" command -v npm 2>/dev/null || true)"
        print "            if [[ -n \"\$system_npm_path\" ]]; then"
        print "                npm_version=\$(\"\$system_npm_path\" --version 2>/dev/null | head -n1 || true)"
        print "            fi"
        print "            if [[ -n \"\$npm_version\" ]]; then"
        print "                log_success \"System npm ready (\$npm_version) at \${system_npm_path}\""
        print "                return 0"
        print "            fi"
        print "            log_error \"npm installation finished but npm not found on PATH.\""
        print "            return 1"
        print "        else"
        print "            log_error \"Failed to install/update system npm\""
        print "            return 1"
        print "        fi"
        print "    }"
        print ""
        print "    if [[ -z \"\$system_npm_path\" ]]; then"
        print "        printf \"\${YELLOW}[WARNING]\${NC} System npm not found. Claude MCP servers (used by Claude Code) need a system-level npm to install MCP packages.\\n\""
        print "        printf \"Recommended command: \${CYAN}%s\${NC}\\n\" \"\$install_cmd\""
        print "        if [[ \"\$AUTO_YES\" == true ]]; then"
        print "            install_system_npm || printf \"\${YELLOW}[WARNING]\${NC} Could not install system npm automatically; continuing, but Claude MCP may fail.\\n\""
        print "        else"
        print "            printf \"Install system npm now? [y/N]: \""
        print "            read -r response"
        print "            case \"\$response\" in"
        print "                [Yy]|[Yy][Ee][Ss]) install_system_npm || printf \"\${YELLOW}[WARNING]\${NC} System npm install failed; continuing, but Claude MCP may fail.\\n\" ;;"
        print "                *) printf \"\${YELLOW}[WARNING]\${NC} Proceeding without system npm. Claude MCP features may not work until you install it.\\n\" ;;"
        print "            esac"
        print "        fi"
        print "    elif [[ -n \"\$npm_version\" ]]; then"
        print "        if version_ge \"\$npm_version\" \"\$MIN_NPM_VERSION\"; then"
        print "            printf \"\${BLUE}[INFO]\${NC} System npm found: %s (at %s)\\n\" \"\$npm_version\" \"\$system_npm_path\""
        print "            return 0"
        print "        fi"
        print "        printf \"\${YELLOW}[WARNING]\${NC} System npm %s is below required %s.\\n\" \"\$npm_version\" \"\$MIN_NPM_VERSION\""
        print "        printf \"Update system npm now? [y/N]: \""
        print "        read -r resp_update"
        print "        case \"\$resp_update\" in"
        print "            [Yy]|[Yy][Ee][Ss])"
        print "                install_system_npm || printf \"\${YELLOW}[WARNING]\${NC} System npm update failed; continuing, but Claude MCP may fail.\\n\""
        print "                ;;"
        print "            *)"
        print "                printf \"\${YELLOW}[WARNING]\${NC} Skipping system npm update. Claude MCP features may not work until you update it.\\n\""
        print "                ;;"
        print "        esac"
        print "    fi"
        print ""
        print "    return 0"
        print "}"
        skip_next = 100  # Skip the old implementation
        next
    }
    skip_next > 0 {
        skip_next--
        next
    }
    { print }
    ' "$SCRIPT_PATH" > "$temp_file"
    mv "$temp_file" "$SCRIPT_PATH"

    log_success "  Fixed PATH race condition with explicit path resolution"
}

# Fix BUG-001: Fix array indexing when npm tool is dynamically added
fix_bug_001_array_indexing() {
    log_info "Applying BUG-001: Fixing array indexing for dynamic npm tool..."

    # The issue is in initialize_tools() where npm is added before regular tools
    # but the cache arrays are indexed assuming npm is not present
    # We need to ensure LATEST_VERSION_CACHE has the correct size

    local temp_file
    temp_file=$(mktemp)

    awk '
    /^initialize_tools\(\) \{$/ {
        in_init = 1
    }
    in_init && /^    # Conditionally add npm to the tool list/ {
        # Add comment about BUG-001 fix
        print "    # BUG-001: When adding npm dynamically, ensure cache arrays are properly sized"
        print "    # npm is added first (index 0), so cache arrays must account for this"
        print ""
    }
    in_init && /prefetch_latest_versions$/ {
        # After prefetch, add a fix to ensure cache array size
        print
        print "    # BUG-001: Ensure cache array matches tool array size"
        print "    # (handles case where npm was dynamically added)"
        print "    local expected_size=\${#TOOL_NAMES[@]}"
        print "    local cache_size=\${#LATEST_VERSION_CACHE[@]}"
        print "    if [[ \$cache_size -lt \$expected_size ]]; then"
        print "        for ((i=cache_size; i<expected_size; i++)); do"
        print "            LATEST_VERSION_CACHE[i]=\"\""
        print "        done"
        print "    fi"
    }
    { print }
    ' "$SCRIPT_PATH" > "$temp_file"
    mv "$temp_file" "$SCRIPT_PATH"

    log_success "  Fixed array indexing for dynamic npm tool"
}

# Fix PERF-001: Improve GitHub API rate limit handling
fix_perf_001_github_rate_limit() {
    log_info "Applying PERF-001: Improving GitHub API rate limit handling..."

    local temp_file
    temp_file=$(mktemp)

    # Replace the github_api_get_with_retry function
    awk '
    /^github_api_get_with_retry\(\) \{$/ {
        print "github_api_get_with_retry() {"
        print "    local url=\$1"
        print "    local max_retries=3  # PERF-001: Reduced from 5 to fail faster on rate limits"
        print "    local retry_delay=2   # PERF-001: Increased from 1 for longer backoff"
        print ""
        print "    for attempt in \$(seq 1 \$max_retries); do"
        print "        local response"
        print "        local http_code"
        print ""
        print "        # Make request with headers captured"
        print "        response=\$(curl -fsSL -i --max-time 10 \"\$url\" 2>/dev/null)"
        print "        http_code=\$(echo \"\$response\" | grep -i \"^HTTP/\" | awk '\''{print \$2}'\'')"
        print ""
        print "        # Check rate limit from headers"
        print "        check_github_rate_limit \"\$response\""
        print ""
        print "        # PERF-001: Better rate limit handling with exponential backoff"
        print "        if [[ \"\$http_code\" == \"403\" ]]; then"
        print "            if [[ \"\$GITHUB_RATE_LIMIT_REMAINING\" -lt 10 ]]; then"
        print "                local wait_time=\$((GITHUB_RATE_LIMIT_RESET - \$(date +%s) + 5))"
        print "                if [[ \$wait_time -gt 0 ]] && [[ \$attempt -lt \$max_retries ]]; then"
        print "                    log_warning \"GitHub API rate limit exceeded. Waiting \${wait_time}s for reset...\""
        print "                    sleep \"\$wait_time\""
        print "                    continue"
        print "                else"
        print "                    log_error \"GitHub API rate limit exceeded. Please try again after \${wait_time}s.\""
        print "                    return 1"
        print "                fi"
        print "            fi"
        print "        fi"
        print ""
        print "        # Check for successful response"
        print "        if [[ \"\$http_code\" == \"200\" ]]; then"
        print "            # Extract body and return"
        print "            local body"
        print "            body=\$(echo \"\$response\" | sed -n '\''/^{/,$p'\'')"
        print "            echo \"\$body\""
        print "            return 0"
        print "        fi"
        print ""
        print "        # Retry on other errors with exponential backoff"
        print "        if [[ \$attempt -lt \$max_retries ]]; then"
        print "            log_warning \"GitHub API request failed (HTTP \$http_code). Retrying in \${retry_delay}s...\""
        print "            sleep \"\$retry_delay\""
        print "            retry_delay=\$((retry_delay * 2))  # Exponential backoff"
        print "        fi"
        print "    done"
        print ""
        print "    log_error \"Failed to fetch from GitHub API after \$max_retries attempts\""
        print "    return 1"
        print "}"
        skip_next = 40  # Skip the old implementation
        next
    }
    skip_next > 0 {
        skip_next--
        next
    }
    { print }
    ' "$SCRIPT_PATH" > "$temp_file"
    mv "$temp_file" "$SCRIPT_PATH"

    log_success "  Improved GitHub API rate limit handling"
}

# Main execution
main() {
    log_info "Starting performance and logic fixes..."
    log_info ""

    backup_file
    echo ""

    fix_perf_003_add_cache_vars
    fix_perf_003_conda_root
    fix_perf_003_npm_bin
    fix_perf_003_node_bin
    echo ""

    fix_perf_002_stream_versions
    echo ""

    fix_log_002_path_race
    echo ""

    fix_bug_001_array_indexing
    echo ""

    fix_perf_001_github_rate_limit
    echo ""

    log_success "All fixes applied successfully!"
    echo ""
    echo "Summary of fixes applied:"
    echo "  ✓ PERF-003: Cached subprocess paths for npm/conda detection"
    echo "  ✓ PERF-002: Stream version fetch results instead of waiting for all"
    echo "  ✓ LOG-002: Fixed PATH race condition with explicit path resolution"
    echo "  ✓ BUG-001: Fixed array indexing when npm tool is dynamically added"
    echo "  ✓ PERF-001: Improved GitHub API rate limit handling with exponential backoff"
    echo ""
    echo "Please test the updated script before committing:"
    echo "  bash -n $SCRIPT_PATH"
}

# Run main
main "$@"
