#!/usr/bin/env bash
set -euo pipefail

TARGET=${HOME}/.claude.json
BACKUP="${TARGET}.bak.$(date +%s)"
NEWPATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:$HOME/.local/bin:$HOME/.pyenv/shims"

# Create file if missing
[ -f "$TARGET" ] || echo '{}' > "$TARGET"
cp "$TARGET" "$BACKUP"

python3 - "$TARGET" "$NEWPATH" <<'PY'
import json, sys, pathlib
path_file = pathlib.Path(sys.argv[1])
new_path = sys.argv[2]

try:
    data = json.loads(path_file.read_text())
except Exception:
    data = {}

if not isinstance(data, dict):
    data = {}

env = data.get("env")
if not isinstance(env, dict):
    env = {}

# Remove duplicate paths while preserving order
    seen_paths = set()
    unique_path_parts = []
    for path_part in new_path.split(':'):
        if path_part not in seen_paths:
            seen_paths.add(path_part)
            unique_path_parts.append(path_part)
    env["PATH"] = ':'.join(unique_path_parts)

data["env"] = env
path_file.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n")
PY

echo "Updated $TARGET (backup: $BACKUP)"
